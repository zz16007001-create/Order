import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';
import { registerServiceWorker } from './services/swRegister.ts';

registerServiceWorker();

createRoot(document.getElementById('root')!).render(<App />);
