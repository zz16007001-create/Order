/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import { Customer } from '../types';
import { Icon3D } from '../components/icons3d/Icon3D';

export const CustomersPage: React.FC = () => {
  const {
    state,
    customers,
    customerPayments,
    customerNotes,
    addCustomer,
    updateCustomer,
    deleteCustomer,
    addCustomerNote,
    deleteCustomerNote,
    recordCustomerPayment,
    setCurrentPage,
  } = useApp();

  const [selectedCustomerId, setSelectedCustomerId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  // Add customer modal
  const [showAddCustomerModal, setShowAddCustomerModal] = useState(false);
  const [newCustName, setNewCustName] = useState('');
  const [newCustPhone, setNewCustPhone] = useState('');
  const [newCustNotes, setNewCustNotes] = useState('');

  // Collect Payment Modal
  const [paymentCustomerId, setPaymentCustomerId] = useState<string | null>(null);
  const [paymentAmount, setPaymentAmount] = useState('');
  const [paymentDate, setPaymentDate] = useState(new Date().toISOString().split('T')[0]);
  const [paymentNotes, setPaymentNotes] = useState('');

  // Add Note Modal
  const [noteCustomerId, setNoteCustomerId] = useState<string | null>(null);
  const [noteText, setNoteText] = useState('');
  const [noteDate, setNoteDate] = useState(new Date().toISOString().split('T')[0]);

  // Active customer profile tab: 'statement' | 'purchases' | 'payments' | 'notes'
  const [activeCustomerTab, setActiveCustomerTab] = useState<'statement' | 'purchases' | 'payments' | 'notes'>('statement');

  // Customer Summary Statistics
  const customerStatsMap = useMemo(() => {
    const map: Record<string, { totalPurchases: number; totalPaid: number; remainingDebt: number; itemsCount: number }> = {};

    customers.forEach((c) => {
      map[c.id] = { totalPurchases: 0, totalPaid: 0, remainingDebt: 0, itemsCount: 0 };
    });

    state.orders.forEach((ord) => {
      ord.items.forEach((it) => {
        if (it.customerId && it.isSold) {
          if (!map[it.customerId]) {
            map[it.customerId] = { totalPurchases: 0, totalPaid: 0, remainingDebt: 0, itemsCount: 0 };
          }
          const price = (it.soldPrice || 0) * (it.quantity || 1);
          const paid = it.paidAmount !== undefined ? it.paidAmount : price;
          const debt = Math.max(0, price - paid);

          map[it.customerId].totalPurchases += price;
          map[it.customerId].totalPaid += paid;
          map[it.customerId].remainingDebt += debt;
          map[it.customerId].itemsCount += 1;
        }
      });
    });

    return map;
  }, [customers, state.orders]);

  // Overall totals
  const overallTotals = useMemo(() => {
    let debt = 0;
    let purchases = 0;
    let paid = 0;
    Object.values(customerStatsMap).forEach((st) => {
      debt += st.remainingDebt;
      purchases += st.totalPurchases;
      paid += st.totalPaid;
    });
    return { debt, purchases, paid };
  }, [customerStatsMap]);

  // Filtered customers
  const filteredCustomers = useMemo(() => {
    if (!searchQuery.trim()) return customers;
    const q = searchQuery.toLowerCase().trim();
    return customers.filter(
      (c) =>
        c.name.toLowerCase().includes(q) ||
        (c.phone && c.phone.includes(q)) ||
        (c.notes && c.notes.toLowerCase().includes(q))
    );
  }, [customers, searchQuery]);

  // Selected customer object
  const selectedCustomer = useMemo(
    () => customers.find((c) => c.id === selectedCustomerId) || null,
    [customers, selectedCustomerId]
  );

  // Selected customer purchases details
  const selectedCustomerPurchases = useMemo(() => {
    if (!selectedCustomerId) return [];
    const list: Array<{
      itemId: string;
      itemName: string;
      orderCode: string;
      orderDate: string;
      soldDate: string;
      price: number;
      paid: number;
      debt: number;
      paymentType: string;
      quantity: number;
    }> = [];

    state.orders.forEach((ord) => {
      ord.items.forEach((it) => {
        if (it.customerId === selectedCustomerId && it.isSold) {
          const totalSale = (it.soldPrice || 0) * (it.quantity || 1);
          const paid = it.paidAmount !== undefined ? it.paidAmount : totalSale;
          const debt = Math.max(0, totalSale - paid);
          list.push({
            itemId: it.id,
            itemName: it.name,
            orderCode: ord.code,
            orderDate: ord.date,
            soldDate: it.soldDate || ord.date,
            price: totalSale,
            paid,
            debt,
            paymentType: it.paymentType || 'cash',
            quantity: it.quantity || 1,
          });
        }
      });
    });

    return list.sort((a, b) => b.soldDate.localeCompare(a.soldDate));
  }, [selectedCustomerId, state.orders]);

  // Selected customer payments history
  const selectedCustomerPayments = useMemo(() => {
    if (!selectedCustomerId) return [];
    return customerPayments
      .filter((p) => p.customerId === selectedCustomerId)
      .sort((a, b) => b.date.localeCompare(a.date));
  }, [selectedCustomerId, customerPayments]);

  // Selected customer notes history
  const selectedCustomerNotes = useMemo(() => {
    if (!selectedCustomerId) return [];
    return customerNotes
      .filter((n) => n.customerId === selectedCustomerId)
      .sort((a, b) => b.date.localeCompare(a.date));
  }, [selectedCustomerId, customerNotes]);

  // (3) Unified Chronological Statement (كشف حساب زمني موحد برصيد تراكمي)
  const unifiedAccountStatement = useMemo(() => {
    if (!selectedCustomerId) return [];

    type StatementEntry = {
      id: string;
      date: string;
      type: 'purchase' | 'payment' | 'note';
      title: string;
      debit: number; // دين جديد (شراء)
      credit: number; // سداد (دفعة)
      balance: number; // الرصيد التراكمي
      notes?: string;
    };

    const rawTimeline: Array<Omit<StatementEntry, 'balance'>> = [];

    // Purchases
    selectedCustomerPurchases.forEach((p) => {
      rawTimeline.push({
        id: 'purch_' + p.itemId,
        date: p.soldDate,
        type: 'purchase',
        title: `شراء: ${p.itemName} (${p.orderCode})`,
        debit: p.price,
        credit: 0,
        notes: p.debt > 0 ? `متبقي دين ${p.debt} ${state.settings.currency}` : 'مدفوع',
      });
    });

    // Payments
    selectedCustomerPayments.forEach((pay) => {
      rawTimeline.push({
        id: pay.id,
        date: pay.date,
        type: 'payment',
        title: 'تحصيل دفعة نقدية',
        debit: 0,
        credit: pay.amount,
        notes: pay.notes || undefined,
      });
    });

    // Notes
    selectedCustomerNotes.forEach((n) => {
      rawTimeline.push({
        id: n.id,
        date: n.date,
        type: 'note',
        title: 'ملاحظة مسجلة',
        debit: 0,
        credit: 0,
        notes: n.text,
      });
    });

    // Sort chronologically ascending to calculate running balance
    rawTimeline.sort((a, b) => a.date.localeCompare(b.date));

    let runningBalance = 0;
    const computed: StatementEntry[] = [];

    rawTimeline.forEach((item) => {
      runningBalance = runningBalance + item.debit - item.credit;
      computed.push({
        ...item,
        balance: runningBalance,
      });
    });

    // Return reversed so newest events show at the top
    return computed.reverse();
  }, [selectedCustomerId, selectedCustomerPurchases, selectedCustomerPayments, selectedCustomerNotes, state.settings.currency]);

  const handleAddCustomerSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCustName.trim()) return;
    const created = addCustomer(newCustName.trim(), newCustPhone.trim() || undefined, newCustNotes.trim() || undefined);
    setNewCustName('');
    setNewCustPhone('');
    setNewCustNotes('');
    setShowAddCustomerModal(false);
    setSelectedCustomerId(created.id);
  };

  const handleCollectPaymentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const amt = parseFloat(paymentAmount);
    if (!paymentCustomerId || !amt || amt <= 0) return;
    recordCustomerPayment(paymentCustomerId, amt, paymentDate, paymentNotes.trim() || undefined);
    setPaymentAmount('');
    setPaymentNotes('');
    setPaymentCustomerId(null);
  };

  const handleAddNoteSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!noteCustomerId || !noteText.trim()) return;
    addCustomerNote(noteCustomerId, noteText.trim(), noteDate);
    setNoteText('');
    setNoteCustomerId(null);
  };

  return (
    <div className="w-full flex flex-col gap-[13px] text-[#1F1A2E] dark:text-[#F4F0FA]">
      {/* 1. كارت اسم الصفحة: بنفسجي متدرج، ارتفاع 52px */}
      <div className="card-header-purple flex items-center justify-between">
        <div className="flex items-center gap-[8px] min-w-0">
          {selectedCustomer && (
            <button
              onClick={() => setSelectedCustomerId(null)}
              className="btn-back-transparent"
              title="الرجوع لقائمة العملاء"
            >
              ➜
            </button>
          )}
          <span className="text-[18px] font-[800] text-white leading-none whitespace-nowrap">
            {selectedCustomer ? selectedCustomer.name : `سجل العملاء والمديونيات (${customers.length})`}
          </span>
        </div>

        <button
          onClick={() => setShowAddCustomerModal(true)}
          className="h-[26px] px-[10px] rounded-full bg-[#2F7F5F] hover:bg-[#25664C] text-white text-[12px] font-[700] flex items-center gap-1 flex-none shadow-sm cursor-pointer"
        >
          <span className="text-[12px] leading-none">＋</span>
          <span>عميل جديد</span>
        </button>
      </div>

      {/* ========================================================= */}
      {/* VIEW A: DETAILED CUSTOMER PROFILE VIEW                    */}
      {/* ========================================================= */}
      {selectedCustomer ? (
        <div className="w-full flex flex-col gap-[13px]">
          {/* Customer Summary Card */}
          {(() => {
            const st = customerStatsMap[selectedCustomer.id] || { totalPurchases: 0, totalPaid: 0, remainingDebt: 0, itemsCount: 0 };
            return (
              <div className="card-main p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-[14px] font-[800] text-[#1F1A2E] dark:text-[#F4F0FA] flex items-center gap-2">
                      {selectedCustomer.name}
                      {st.remainingDebt > 0 ? (
                        <span className="text-[10px] px-2 py-0.5 rounded-full bg-[#F8E6EC] dark:bg-[#381B26] text-[#A23B5A] dark:text-[#FB7185] font-[700]">
                          مدين
                        </span>
                      ) : (
                        <span className="text-[10px] px-2 py-0.5 rounded-full bg-[#E3F2EA] dark:bg-[#162E23] text-[#2F7F5F] dark:text-[#4BA682] font-[700]">
                          خالص الحساب
                        </span>
                      )}
                    </h3>
                    <span className="text-[11px] font-[600] text-[#666079] dark:text-[#9E97B0]">
                      {selectedCustomer.phone || 'بدون هاتف'} • عميل منذ {selectedCustomer.createdAt}
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => {
                        setNoteCustomerId(selectedCustomer.id);
                        setNoteText('');
                        setNoteDate(new Date().toISOString().split('T')[0]);
                      }}
                      className="h-[28px] px-2.5 rounded-full bg-[#F5F4F9] dark:bg-[#1A1424] text-[11px] font-[700] text-[#1F1A2E] dark:text-[#F4F0FA] cursor-pointer"
                      title="إضافة ملاحظة بتاريخ"
                    >
                      + ملاحظة
                    </button>
                    <button
                      onClick={() => {
                        setPaymentCustomerId(selectedCustomer.id);
                        setPaymentAmount(st.remainingDebt > 0 ? st.remainingDebt.toString() : '');
                        setPaymentDate(new Date().toISOString().split('T')[0]);
                        setPaymentNotes('');
                      }}
                      className="h-[28px] px-3 rounded-full bg-[#2F7F5F] hover:bg-[#25664C] text-white text-[11px] font-[800] cursor-pointer"
                    >
                      تحصيل دفعة
                    </button>
                  </div>
                </div>

                {/* 3 Metric Boxes */}
                <div className="grid grid-cols-3 gap-2 text-center text-xs pt-1 border-t border-[#E4E1EC] dark:border-[#3A3150]">
                  <div className="card-inner">
                    <span className="text-[10px] text-[#666079] dark:text-[#9E97B0] block">إجمالي المشتريات</span>
                    <strong className="text-[12px] font-[800] text-[#1F1A2E] dark:text-[#F4F0FA] tabular-nums">
                      {st.totalPurchases.toLocaleString('en-US')}
                    </strong>
                  </div>
                  <div className="card-inner">
                    <span className="text-[10px] text-[#2F7F5F] dark:text-[#4BA682] block">المحصّل والمدفوع</span>
                    <strong className="text-[12px] font-[800] text-[#2F7F5F] dark:text-[#4BA682] tabular-nums">
                      {st.totalPaid.toLocaleString('en-US')}
                    </strong>
                  </div>
                  <div className={`card-inner ${st.remainingDebt > 0 ? 'bg-[#F8E6EC] dark:bg-[#381B26] text-[#A23B5A] dark:text-[#FB7185]' : ''}`}>
                    <span className="text-[10px] block">المتبقي دين</span>
                    <strong className="text-[12px] font-[800] tabular-nums">
                      {st.remainingDebt.toLocaleString('en-US')} {state.settings.currency}
                    </strong>
                  </div>
                </div>
              </div>
            );
          })()}

          {/* Sub Navigation Bar for Customer Details */}
          <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar p-1 rounded-full card-main">
            {[
              { id: 'statement', label: 'كشف حساب زمني' },
              { id: 'purchases', label: 'المشتريات التفصيلية' },
              { id: 'payments', label: 'سجل التحصيلات' },
              { id: 'notes', label: 'ملاحظات العميل' },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveCustomerTab(tab.id as any)}
                className={`flex-1 py-1 px-2.5 rounded-full text-[11px] font-[700] text-center whitespace-nowrap transition cursor-pointer ${
                  activeCustomerTab === tab.id
                    ? 'bg-[#5F2967] text-white shadow-xs'
                    : 'text-[#666079] dark:text-[#9E97B0]'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {/* (1) TAB: كشف الحساب الزمني الموحد (شراء / دفعة / ملاحظة برصيد تراكمي) */}
          {activeCustomerTab === 'statement' && (
            <div className="card-main p-4 space-y-2.5">
              <span className="text-xs font-extrabold text-[#5F2967] dark:text-[#9B67A4] block">
                كشف الحساب الزمني الموحد (الرصيد التراكمي):
              </span>

              {unifiedAccountStatement.length === 0 ? (
                <p className="text-center text-xs text-[#9A98B0] py-6">لا توجد عمليات مسجلة للعميل</p>
              ) : (
                <div className="divide-y divide-[#ECECF4] dark:divide-[#32263F]">
                  {unifiedAccountStatement.map((st) => (
                    <div key={st.id} className="py-2.5 first:pt-0 last:pb-0 flex items-center justify-between gap-2.5 text-xs">
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-1.5">
                          <span
                            className={`w-2 h-2 rounded-full shrink-0 ${
                              st.type === 'purchase'
                                ? 'bg-[#E2574C]'
                                : st.type === 'payment'
                                ? 'bg-[#2FA36B]'
                                : 'bg-purple-400'
                            }`}
                          />
                          <strong className="font-bold text-[#2B2340] dark:text-white truncate block">
                            {st.title}
                          </strong>
                        </div>
                        <span className="text-[10px] text-[#9A98B0] block pr-3.5">
                          {st.date} {st.notes && `• ${st.notes}`}
                        </span>
                      </div>

                      <div className="text-left shrink-0">
                        {st.type === 'purchase' && (
                          <span className="font-black text-xs text-[#E2574C] tabular-nums block">
                            +{st.debit.toLocaleString('en-US')} (دين)
                          </span>
                        )}
                        {st.type === 'payment' && (
                          <span className="font-black text-xs text-[#2FA36B] tabular-nums block">
                            -{st.credit.toLocaleString('en-US')} (سداد)
                          </span>
                        )}
                        <span className="text-[10px] font-bold text-slate-500 tabular-nums">
                          الرصيد: {st.balance.toLocaleString('en-US')} {state.settings.currency}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* (2) TAB: مشتريات العميل بالتفصيل */}
          {activeCustomerTab === 'purchases' && (
            <div className="p-3.5 rounded-3xl bg-white dark:bg-[#231A2C] border border-[#ECECF4] dark:border-[#32263F] wallet-card-shadow space-y-2">
              <span className="text-xs font-extrabold text-[#2B2340] dark:text-white block">
                مشتريات العميل ({selectedCustomerPurchases.length} صنف):
              </span>

              {selectedCustomerPurchases.length === 0 ? (
                <p className="text-center text-xs text-[#9A98B0] py-6">لم يقم العميل بشراء أي أصناف بعد</p>
              ) : (
                <div className="space-y-2">
                  {selectedCustomerPurchases.map((p) => (
                    <div
                      key={p.itemId}
                      className="p-3 rounded-2xl bg-[#F1F1FA] dark:bg-[#17101D] border border-[#ECECF4] dark:border-[#32263F] space-y-1.5 text-xs"
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-xs text-[#2B2340] dark:text-white">
                          {p.itemName} ({p.quantity} قطعة)
                        </span>
                        <span className="text-[10px] px-2 py-0.5 rounded-md bg-white dark:bg-[#231A2C] font-bold text-[#5F2967] dark:text-[#9B67A4]">
                          {p.orderCode}
                        </span>
                      </div>

                      <div className="grid grid-cols-3 gap-1.5 text-[11px] pt-1 border-t border-[#ECECF4] dark:border-[#32263F]">
                        <div>
                          <span className="text-[9px] text-[#9A98B0] block">إجمالي السعر:</span>
                          <strong className="text-[#2B2340] dark:text-white tabular-nums font-black">{p.price}</strong>
                        </div>
                        <div>
                          <span className="text-[9px] text-[#2FA36B] block">المدفوع:</span>
                          <strong className="text-[#2FA36B] tabular-nums font-black">{p.paid}</strong>
                        </div>
                        <div>
                          <span className="text-[9px] text-[#E2574C] block">المتبقي:</span>
                          <strong className={`tabular-nums font-black ${p.debt > 0 ? 'text-[#E2574C]' : 'text-[#2FA36B]'}`}>
                            {p.debt > 0 ? p.debt : 'خالص'}
                          </strong>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* (3) TAB: سجل التحصيلات */}
          {activeCustomerTab === 'payments' && (
            <div className="card-main p-4 space-y-2">
              <span className="text-[12px] font-[800] text-[#2F7F5F] dark:text-[#4BA682] block">
                سجل التحصيلات والدفعات ({selectedCustomerPayments.length}):
              </span>

              {selectedCustomerPayments.length === 0 ? (
                <p className="text-center text-[12px] text-[#666079] dark:text-[#9E97B0] py-6">لا توجد دفعات محصلة حتى الآن</p>
              ) : (
                <div className="divide-y divide-[#E4E1EC] dark:divide-[#3A3150]">
                  {selectedCustomerPayments.map((pay) => (
                    <div key={pay.id} className="py-2.5 flex items-center justify-between text-xs">
                      <div>
                        <strong className="text-[#2F7F5F] dark:text-[#4BA682] font-[800] block text-[12px]">
                          تحصيل: {pay.amount.toLocaleString('en-US')} {state.settings.currency}
                        </strong>
                        <span className="text-[10px] text-[#666079] dark:text-[#9E97B0]">
                          {pay.date} {pay.notes && `• ${pay.notes}`}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* (4) TAB: الملاحظات الزمانية الحرة */}
          {activeCustomerTab === 'notes' && (
            <div className="card-main p-4 space-y-2.5">
              <div className="flex items-center justify-between">
                <span className="text-xs font-extrabold text-[#5F2967] dark:text-[#9B67A4]">
                  ملاحظات ومواعيد العميل ({selectedCustomerNotes.length}):
                </span>
                <button
                  onClick={() => {
                    setNoteCustomerId(selectedCustomer.id);
                    setNoteText('');
                    setNoteDate(new Date().toISOString().split('T')[0]);
                  }}
                  className="px-2.5 py-1 rounded-xl bg-[#5F2967] text-white text-[10px] font-bold cursor-pointer"
                >
                  + إضافة ملاحظة
                </button>
              </div>

              {selectedCustomerNotes.length === 0 ? (
                <p className="text-center text-xs text-[#9A98B0] py-6">لا توجد ملاحظات مسجلة</p>
              ) : (
                <div className="space-y-2">
                  {selectedCustomerNotes.map((n) => (
                    <div
                      key={n.id}
                      className="p-3 rounded-2xl bg-[#F1F1FA] dark:bg-[#17101D] border border-[#ECECF4] dark:border-[#32263F] flex items-start justify-between gap-2 text-xs"
                    >
                      <div>
                        <span className="text-[10px] font-bold text-[#5F2967] dark:text-[#9B67A4] block">
                          بتاريخ: {n.date}
                        </span>
                        <p className="text-[#2B2340] dark:text-white mt-1 leading-relaxed">{n.text}</p>
                      </div>
                      <button
                        onClick={() => deleteCustomerNote(n.id)}
                        className="text-slate-400 hover:text-rose-500 p-1 cursor-pointer"
                        title="حذف الملاحظة"
                      >
                        <Icon3D name="trash" size={14} />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      ) : (
        /* ========================================================= */
        /* VIEW B: ALL CUSTOMERS LIST                                */
        /* ========================================================= */
        <div className="w-full flex flex-col gap-[13px]">
          {/* Overall Debt Summary Box: Solid Teal Hero Card */}
          <div className="w-full h-[92px] card-hero-teal relative px-[15px] flex items-center justify-between">
            <div>
              <span className="text-[11px] font-[600] text-white/85 leading-none mb-[6px] block">
                إجمالي ديون العملاء المطلوبة
              </span>
              <div className="flex items-baseline gap-[8px]">
                <span className="text-[30px] font-[900] leading-none text-white tabular-nums">
                  {overallTotals.debt.toLocaleString('en-US')}
                </span>
                <span className="text-[13px] font-[700] text-white/85 leading-none">
                  {state.settings.currency}
                </span>
              </div>
            </div>
            <div className="text-left text-[12px] font-[700] text-white/90 space-y-1 shrink-0">
              <div>المشتريات: {overallTotals.purchases.toLocaleString('en-US')}</div>
              <div>المحصّل: {overallTotals.paid.toLocaleString('en-US')}</div>
            </div>
          </div>

          {/* Search Bar: Capsule 34px, font 12px, borderless, card-main shadow */}
          <div className="w-full h-[34px] rounded-full card-main px-3 flex items-center gap-2">
            <div className="text-[#666079] dark:text-[#9E97B0] shrink-0">
              <Icon3D name="search" size={15} />
            </div>
            <input
              type="text"
              placeholder="بحث باسم العميل أو رقم الهاتف..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-transparent border-none outline-none text-[12px] font-[700] text-[#1F1A2E] dark:text-[#F4F0FA] placeholder:text-[#666079] dark:placeholder:text-[#9E97B0]"
            />
          </div>

          {/* Customers Cards List */}
          {filteredCustomers.length === 0 ? (
            <div className="py-8 text-center border-[1.5px] border-dashed border-[#D4D0E0] dark:border-[#3A3150] rounded-[14px] bg-white dark:bg-[#211A2D] p-5 text-[12px] font-[600] text-[#666079] dark:text-[#9E97B0]">
              لا يوجد عملاء مسجلين حالياً. اضغط "عميل جديد" لإضافة أول عميل.
            </div>
          ) : (
            <div className="w-full flex flex-col gap-[13px]">
              {filteredCustomers.map((cust) => {
                const st = customerStatsMap[cust.id] || { totalPurchases: 0, totalPaid: 0, remainingDebt: 0, itemsCount: 0 };
                return (
                  <div
                    key={cust.id}
                    onClick={() => setSelectedCustomerId(cust.id)}
                    className="card-main p-3.5 cursor-pointer space-y-2.5"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2.5 min-w-0">
                        <div className="w-[32px] h-[32px] rounded-full bg-[#F1E8F4] dark:bg-[#2D1F35] text-[#5F2967] dark:text-[#D8B4FE] flex items-center justify-center shrink-0">
                          <Icon3D name="customers" size={16} />
                        </div>
                        <div className="min-w-0">
                          <h4 className="text-[14px] font-[800] text-[#1F1A2E] dark:text-[#F4F0FA] truncate leading-tight">
                            {cust.name}
                          </h4>
                          <span className="text-[11px] font-[600] text-[#666079] dark:text-[#9E97B0] block truncate leading-tight mt-0.5">
                            {cust.phone || 'بدون هاتف'} • {st.itemsCount} صنف مشتريات
                          </span>
                        </div>
                      </div>

                      <div className="text-left shrink-0">
                        <span className="text-[11px] font-[600] text-[#666079] dark:text-[#9E97B0] block leading-tight">الدين المتبقي:</span>
                        <strong className={`text-[14px] font-[800] tabular-nums leading-tight ${st.remainingDebt > 0 ? 'text-[#A23B5A] dark:text-[#FB7185]' : 'text-[#2F7F5F] dark:text-[#4BA682]'}`}>
                          {st.remainingDebt > 0 ? `${st.remainingDebt.toLocaleString('en-US')} ${state.settings.currency}` : 'خالص'}
                        </strong>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-2 text-[11px] font-[600] pt-1.5 border-t border-[#E4E1EC] dark:border-[#3A3150]">
                      <span className="text-[#666079] dark:text-[#9E97B0]">
                        إجمالي الشراء: <strong className="text-[#1F1A2E] dark:text-[#F4F0FA] font-[700] tabular-nums">{st.totalPurchases.toLocaleString('en-US')}</strong>
                      </span>
                      <span className="text-[#2F7F5F] dark:text-[#4BA682] text-left">
                        المسدد: <strong className="font-[700] tabular-nums">{st.totalPaid.toLocaleString('en-US')}</strong>
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* MODAL 1: Add New Customer */}
      {showAddCustomerModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <form
            onSubmit={handleAddCustomerSubmit}
            className="w-full max-w-xs bg-white dark:bg-[#231A2C] rounded-3xl p-5 border border-[#ECECF4] dark:border-[#32263F] space-y-3.5 text-right text-xs shadow-2xl"
          >
            <div className="flex items-center justify-between pb-1 border-b border-[#ECECF4] dark:border-[#32263F]">
              <h3 className="font-extrabold text-sm text-[#2B2340] dark:text-white">
                إضافة عميل جديد
              </h3>
              <button
                type="button"
                onClick={() => setShowAddCustomerModal(false)}
                className="text-[#9A98B0] hover:text-[#2B2340]"
              >
                <Icon3D name="close" size={16} />
              </button>
            </div>

            <div>
              <label className="block font-bold text-[#2B2340] dark:text-white mb-1">اسم العميل *</label>
              <input
                type="text"
                required
                autoFocus
                placeholder="الاسم ثلاثي..."
                value={newCustName}
                onChange={(e) => setNewCustName(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-[#ECECF4] dark:border-[#32263F] bg-[#F1F1FA] dark:bg-[#17101D] font-bold outline-none focus:border-[#5F2967]"
              />
            </div>

            <div>
              <label className="block font-bold text-[#2B2340] dark:text-white mb-1">رقم الهاتف</label>
              <input
                type="tel"
                placeholder="01..."
                value={newCustPhone}
                onChange={(e) => setNewCustPhone(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-[#ECECF4] dark:border-[#32263F] bg-[#F1F1FA] dark:bg-[#17101D] outline-none"
              />
            </div>

            <div>
              <label className="block font-bold text-[#2B2340] dark:text-white mb-1">ملاحظات أولية</label>
              <input
                type="text"
                placeholder="العنوان، ملاحظات..."
                value={newCustNotes}
                onChange={(e) => setNewCustNotes(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-[#ECECF4] dark:border-[#32263F] bg-[#F1F1FA] dark:bg-[#17101D] outline-none"
              />
            </div>

            <div className="flex gap-2 pt-1">
              <button
                type="submit"
                className="flex-1 py-2.5 rounded-xl bg-[#5F2967] hover:bg-[#4A1E52] text-white font-bold text-xs shadow-xs transition cursor-pointer"
              >
                إضافة العميل
              </button>
              <button
                type="button"
                onClick={() => setShowAddCustomerModal(false)}
                className="px-4 py-2.5 rounded-xl bg-[#ECECF4] dark:bg-[#32263F] text-xs font-bold cursor-pointer"
              >
                إلغاء
              </button>
            </div>
          </form>
        </div>
      )}

      {/* MODAL 2: Collect Payment (تحصيل دفعة) */}
      {paymentCustomerId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <form
            onSubmit={handleCollectPaymentSubmit}
            className="w-full max-w-xs bg-white dark:bg-[#231A2C] rounded-3xl p-5 border border-[#ECECF4] dark:border-[#32263F] space-y-3.5 text-right text-xs shadow-2xl"
          >
            <div className="flex items-center justify-between pb-1 border-b border-[#ECECF4] dark:border-[#32263F]">
              <h3 className="font-extrabold text-sm text-[#2FA36B] flex items-center gap-1.5">
                <Icon3D name="money_in" size={20} />
                تحصيل دفعة نقدية
              </h3>
              <button
                type="button"
                onClick={() => setPaymentCustomerId(null)}
                className="text-[#9A98B0] hover:text-[#2B2340]"
              >
                <Icon3D name="close" size={16} />
              </button>
            </div>

            <div>
              <label className="block font-bold text-[#2B2340] dark:text-white mb-1">المبلغ المحصل *</label>
              <input
                type="number"
                step="any"
                required
                autoFocus
                placeholder="0.00"
                value={paymentAmount}
                onChange={(e) => setPaymentAmount(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-[#ECECF4] dark:border-[#32263F] bg-[#F1F1FA] dark:bg-[#17101D] font-black text-center text-base outline-none focus:border-[#2FA36B]"
              />
            </div>

            <div>
              <label className="block font-bold text-[#2B2340] dark:text-white mb-1">تاريخ التحصيل</label>
              <input
                type="date"
                required
                value={paymentDate}
                onChange={(e) => setPaymentDate(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-[#ECECF4] dark:border-[#32263F] bg-[#F1F1FA] dark:bg-[#17101D] outline-none"
              />
            </div>

            <div>
              <label className="block font-bold text-[#2B2340] dark:text-white mb-1">ملاحظة</label>
              <input
                type="text"
                placeholder="طريقة التحصيل، ملاحظات..."
                value={paymentNotes}
                onChange={(e) => setPaymentNotes(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-[#ECECF4] dark:border-[#32263F] bg-[#F1F1FA] dark:bg-[#17101D] outline-none"
              />
            </div>

            <p className="text-[10px] text-slate-500 bg-slate-100 dark:bg-slate-800/60 p-2 rounded-xl">
              * يتم توزيع الدفعة تلقائياً على أقدم الأصناف الآجلة أولاً (FIFO) وتحديث المتبقي في الأوردرات.
            </p>

            <div className="flex gap-2 pt-1">
              <button
                type="submit"
                className="flex-1 py-2.5 rounded-xl bg-[#2FA36B] hover:bg-emerald-700 text-white font-black text-xs shadow-xs transition cursor-pointer"
              >
                تأكيد التحصيل
              </button>
              <button
                type="button"
                onClick={() => setPaymentCustomerId(null)}
                className="px-4 py-2.5 rounded-xl bg-[#ECECF4] dark:bg-[#32263F] text-xs font-bold cursor-pointer"
              >
                إلغاء
              </button>
            </div>
          </form>
        </div>
      )}

      {/* MODAL 3: Add Date-Stamped Note */}
      {noteCustomerId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <form
            onSubmit={handleAddNoteSubmit}
            className="w-full max-w-xs bg-white dark:bg-[#231A2C] rounded-3xl p-5 border border-[#ECECF4] dark:border-[#32263F] space-y-3.5 text-right text-xs shadow-2xl"
          >
            <div className="flex items-center justify-between pb-1 border-b border-[#ECECF4] dark:border-[#32263F]">
              <h3 className="font-extrabold text-sm text-[#5F2967] dark:text-[#9B67A4]">
                إضافة ملاحظة بتاريخ
              </h3>
              <button
                type="button"
                onClick={() => setNoteCustomerId(null)}
                className="text-[#9A98B0] hover:text-[#2B2340]"
              >
                <Icon3D name="close" size={16} />
              </button>
            </div>

            <div>
              <label className="block font-bold text-[#2B2340] dark:text-white mb-1">التاريخ</label>
              <input
                type="date"
                required
                value={noteDate}
                onChange={(e) => setNoteDate(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-[#ECECF4] dark:border-[#32263F] bg-[#F1F1FA] dark:bg-[#17101D] outline-none"
              />
            </div>

            <div>
              <label className="block font-bold text-[#2B2340] dark:text-white mb-1">الملاحظة *</label>
              <textarea
                required
                rows={3}
                placeholder="مثال: وعد بدفع 500 يوم الأحد..."
                value={noteText}
                onChange={(e) => setNoteText(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-[#ECECF4] dark:border-[#32263F] bg-[#F1F1FA] dark:bg-[#17101D] outline-none"
              />
            </div>

            <div className="flex gap-2 pt-1">
              <button
                type="submit"
                className="flex-1 py-2 rounded-xl bg-[#5F2967] text-white font-bold text-xs cursor-pointer hover:bg-[#4A1E52]"
              >
                حفظ الملاحظة
              </button>
              <button
                type="button"
                onClick={() => setNoteCustomerId(null)}
                className="px-4 py-2 rounded-xl bg-[#ECECF4] dark:bg-[#32263F] text-xs font-bold cursor-pointer"
              >
                إلغاء
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
